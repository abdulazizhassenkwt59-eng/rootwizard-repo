#!/data/data/com.termux/files/usr/bin/bash
echo "=== Network Check ==="
command -v ip >/dev/null 2>&1 && ip -brief addr || ifconfig 2>/dev/null || true
command -v curl >/dev/null 2>&1 && curl -sI --max-time 4 https://1.1.1.1 | head -n 1 || true
