#!/data/data/com.termux/files/usr/bin/bash
echo "=== System & Termux Info ==="
uname -a
echo "Uptime: $(uptime -p 2>/dev/null || cat /proc/uptime)"
echo "Free memory: $(free -h 2>/dev/null | awk '/Mem:/ {print $4 "/" $2}' || true)"
