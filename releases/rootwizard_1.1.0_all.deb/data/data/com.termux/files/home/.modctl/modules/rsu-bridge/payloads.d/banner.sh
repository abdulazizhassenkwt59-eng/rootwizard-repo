#!/data/data/com.termux/files/usr/bin/bash
export RSU_BRIDGE_ACTIVE="1"
