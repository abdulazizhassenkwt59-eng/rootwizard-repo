#!/data/data/com.termux/files/usr/bin/bash
set -u
LOG_FILE="${RSU_CMD_LOG:-/data/data/com.termux/files/usr/tmp/rsu-commands.log}"
mkdir -p "$(dirname "$LOG_FILE")"
printf '[%s] cmd=%s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$LOG_FILE"
